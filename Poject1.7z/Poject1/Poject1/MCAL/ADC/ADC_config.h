/*
 * ADC_config.h
 *
 * Created: 6/17/2023 12:05:39 PM
 *  Author: Mayer
 */ 


#ifndef ADC_CONFIG_H_
#define ADC_CONFIG_H_





#endif /* ADC_CONFIG_H_ */