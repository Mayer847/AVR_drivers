/*
 * EXTI1_config.h
 *
 * Created: 6/17/2023 8:59:43 AM
 *  Author: Mayer
 */ 


#ifndef EXTI1_CONFIG_H_
#define EXTI1_CONFIG_H_





#endif /* EXTI1_CONFIG_H_ */