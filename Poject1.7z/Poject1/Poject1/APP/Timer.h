
#ifndef TIMER_H_
#define TIMER_H_


static u8 tmr_count=0;

void Timer_kpBuzzer(){
	while(KP_getChar()==NOT_PRESSED){}
		u8 temp=KP_getChar();
	if(temp=='0')
	{
		Timer_compMatch(20);
		LCD_voidPrintNum(20);
	}
	else if(temp=='=')
	{
		Timer_compMatch(40);
		LCD_voidPrintNum(40);
	}
	else if(temp=='+')
	{
		Timer_compMatch(70);
		LCD_voidPrintNum(70);
	}
	else if(temp=='A')
	{
		Timer_compMatch(90);
		LCD_voidPrintNum(90);
	}
}

void Timer_tglLed(){
	/* Timer LED Toggle every 1 second */
	if(tmr_count==61){
		
		Dio_voidSetPinValue(PORT_A,PIN4,HIGH);
	}
	else if(tmr_count==122){
		tmr_count=0;
		Dio_voidSetPinValue(PORT_A,PIN4,LOW);
	}
}


void led_tmr()
{
	tmr_count++;
}

#endif