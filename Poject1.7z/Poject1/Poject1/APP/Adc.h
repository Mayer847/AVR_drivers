
#ifndef ADC_H_
#define ADC_H_

static u8 adc_flag=0;
static u16 LDR_reading=0;

void LDR_read(){
/* ADC polling LDR*/
	/* needs further testing */
	/*LCD_voidCls();
	_delay_ms(100);*/
/* LDR (using ADC interrupt) testing */
	if(adc_flag)
	{
	/*(5000UL* (u16) ADC_read(ADC0))/1024;*/
		LDR_reading= ((u16) (5000UL* ADC_read(ADC0)))/1024;			/* casting because number is too big */
		LCD_voidCls();
		LCD_voidPrintNum(LDR_reading);
		_delay_ms(400);
	}	
	
}

void ADC_flag()
{
	adc_flag=1;
}

#endif /* ADC_H_ */