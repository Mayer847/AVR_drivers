#ifndef EXTINT_H_
#define EXTINT_H_


static u8 cntFlag=0;
static u8 temp=0;
static u8 counter=0;

/*void EXTI1_reset();*/

void ExtInt_kpCntr(){
		
/* interrupt 1 counter '+' switch(Row 4, col 4)*/
	if(cntFlag==1){
		temp=KP_getChar();
		if(temp=='+')
		{
			LCD_voidCls();
			counter++;
			LCD_voidPrintNum(counter);
		}
		else if (temp == '/')	/* start timer with external interrupt one using switch '/'	*/
		{
			Timer_start(PRS1024);
				
		}
		else if (temp== '*')
		{
			/*Dio_voidSetPinValue(PORT_A,PIN4,LOW);*/
			Timer_stop();
		}
	}
}



void EXTI1_flag()
{
	cntFlag=1;
}

/*
void EXTI1_reset(){
	while(get_KP()==NOT_PRESSED){}
	if(get_KP()=='-')
	{
		counter=0;
	}
	LCD_voidCls();
	LCD_voidPrintNum(counter);
}*/


#endif