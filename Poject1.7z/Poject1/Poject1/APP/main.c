/*define cpu 16 MHz clock external clock*/
#define F_CPU 16000000UL	
/*delay*/
#include <util/delay.h>
/*MCAL*/
#include "../MCAL/DIO/Dio_interface.h"
#include "../MCAL/GIE/GIE_interface.h"
#include "../MCAL/EXTI0/EXTI0_interface.h"
#include "../MCAL/EXTI1/EXTI1_interface.h"
#include "../MCAL/ADC/ADC_interface.h"
#include "../MCAL/TIMER/TIMER_interface.h"
/*HAL*/
#include "../HAL/LED/LED_interface.h"
#include "../HAL/SW/SW_interface.h"
#include "../HAL/LCD/LCD_interface.h"

/*APP (FUNCTIONS) */
#include "Timer.h"
#include "Extint.h"

int main(void)
{
/**************** SETTING PIN DIRECTION **********/

	Dio_voidSetPinDirection(PORT_A,PIN4,OUTPUT);/*LED*/
	Dio_voidSetPinDirection(PORT_A,PIN0,INPUT);/*LDR*/
	Dio_voidSetPinDirection(PORT_C,PIN6,OUTPUT);/*BUZZER*/
	Dio_voidSetPinDirection(PORT_B,PIN3,OUTPUT);/*CTC or FAST WPM*/
	
/**************** INITIALIZATION ****************/
	/*LCD & keypad*/
	LCD_init();
	KP_init();
	
	/*ADC*/
	/*init_ADC(AVCC,DIV_FAC_2_0);*/
	
	/*TIMER*/
	/*Timer_init(CTC,PRS1024);*/
	Timer_init(NORMAL,PRS1024);
	/*Timer_init(FAST_PWM,PRS1024);*/
	
/******************* INTERRUPTS ******************/	

/*Enable all interrupts( GLOBAL)*/
	gie_enable();/* must disable with timer, but why? */
	
/*external interrupts*/
	/*EXT0_init();*/
	EXT1_init();
	
/*ADC interrupts*/
	/*ADCI_EN();*/
	
/*call back functions*/
	callback_exti1(&EXTI1_flag);
	/*callback_exti1(&EXTI1_reset);*/ /* under development */
	/*callback_ADC(&ADC_LDR);*/
	callback_tmr(&led_tmr);
	
/*enabling interrupts (GICR)*/
	/*EXTI0_en();*/	/*under development*/
	EXTI1_en();

/******************	TESTING ******************/

	while(1){

	/* ADC - LDR and potentiometer */
		
	/* fast PWM testing with buzzer on KP (FAST_PWM mode) */
		/*Timer_kpBuzzer();*/
		
	/* Timer to toggle LED every second + stop using ext. interrupt on KP (NORMAL mode)*/
		Timer_tglLed();
		
	/* interrupt counter using timer (NORMAL mode) */	
		ExtInt_kpCntr();
	}
}


/*Dio_voidSetPinDirection(u8 PORTID, u8 PINID, u8 Direction);
Dio_voidSetPinValue(u8 PORTID, u8 PINID, u8 Value);
Dio_u8GetPinValue(u8 PORTID, u8 PINID);
Dio_voidTogglePin(u8 PORTID, u8 PIND);
Dio_voidSetPortValue(u8 PORTID, u8 Value);
Dio_voidSetPortDirection(u8 PORTID, u8  Direction);*/

/******direct SWITCH LED *******/

/*LED_voidON(PORT_A,PIN4);
		_delay_ms(1000);
		LED_voidOFF(PORT_A,PIN4);
		_delay_ms(1000);
		
		if(get_u8SwSt(PORT_D,PIN7)==ON){
			LED_voidON(PORT_A,PIN4);
			_delay_ms(500);
		}
		else if(get_u8SwSt(PORT_D,PIN7)==OFF){
			LED_voidOFF(PORT_A,PIN4);
			//_delay_ms(1000);
		}*/

//Dio_voidSetPinDirection(PORT_C,PIN1,OUTPUT);


