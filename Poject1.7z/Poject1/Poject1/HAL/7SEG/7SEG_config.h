/*
 * _7SEG_config.h
 *
 * Created: 6/10/2023 11:16:25 PM
 *  Author: Mayer
 */ 


#ifndef 7SEG_CONFIG_H_
#define 7SEG_CONFIG_H_





#endif /* 7SEG_CONFIG_H_ */