/*
 * TIMER1_prog.c
 *
 * Created: 6/19/2023 2:19:26 PM
 *  Author: Mayer
 */ 

#include "../../LIB/STD_TYPES.h"
#include "../../LIB/BIT_MATH.h"
#include "TIMER1_interface.h"
#include "../DIO/Dio_interface.h"
static void (*pf_tmr1) (void);

void Timer1_init(u8 WGM_mode, u8 clock_select){
	
	SET_BIT(TIMSK_REG,TOIE0);
	
	switch (WGM_mode)
	{
		case NORMAL:
			
			break;
		case PWM:
			break;
		case CTC:
			break;
		case FAST_PWM:
			
			break;
	}
	

	switch(clock_select)
	{
		case NO_CLOCK:
			
		case NO_PRS:
			
		case PRS8:
			
		case PRS64:
		
		case PRS256:
		
		case PRS1024:
			
		case EXT_CLK_F:
			
		case EXT_CLK_R:
			
	}
	if(WGM_mode==CTC || WGM_mode==FAST_PWM)
	{
		Dio_voidSetPinDirection(PORT_B,PIN3,OUTPUT); /*e OC0 pin must be set in order to enable the output driver.*/
		/*Bit 5:4 � COM01:0: Compare Match Output Mode*/
		CLR_BIT(TCCR0,COM00);
		SET_BIT(TCCR0,COM01);/*OVERRIDES THE NORMAL PORT FUNCTIONALITY OF I/O PIN IT IS CONNECTED TO*/
	}
	
}

void Timer1_setComOutModeNon(u8 comOutNon)
{
	Dio_voidSetPinDirection(PORT_B,PIN3,OUTPUT);
	switch(comOutNon)
	{
		case NORM_OC0:
			break;
		case TGL_OC0:	 
			break;
		case CLR_OC0:	 
			break;
		case SET_OC0:	 
			break;
	}
}

void Timer1_compMatch(u8 compMatchOutput)
{
	OCR0 = compMatchOutput*255/100;
}

void Timer1_setComOutMOdeFast(u8 comOutFast)
{
	Dio_voidSetPinDirection(PORT_B,PIN3,OUTPUT);
	switch(comOutFast)
	{
		case NORM_OC0:
		break;
		case CLR_OC0:
		break;
		case SET_OC0:
		break;
	}
}
void Timer1_stop(){
	//CS02 CS01 CS00 => 000
	TCCR0_REG->TCCR0_CS0=NO_CLOCK;
}

void Timer1_start(u8 clock_select){
	/* counter or timer? last three options in the table are for counter */
		switch(clock_select)
		{
			case NO_PRS:
				break;
			case PRS8:
				break;
			case PRS64:
				break;
			case PRS256:
				break;
			case PRS1024:
				break;
			case EXT_CLK_F:
				break;
			case EXT_CLK_R:
				break;
		}
}

void callback_tmr1(void (*function_name)(void))
{
	if (function_name!= NULL)
	{
		pf_tmr1=function_name;
	}

}

void __vector_5 (void) __attribute__((signal,used));

void __vector_5 (void)
{
	
	pf_tmr1();

}