/*
 * TIMER1_private.h
 *
 * Created: 6/19/2023 2:21:02 PM
 *  Author: Mayer
 */ 


#ifndef TIMER1_PRIVATE_H_
#define TIMER1_PRIVATE_H_

#define TCCR1A	*((volatile u8*) 0x4f)
#define TCCR1B  *((volatile u8*) 0x4e)



#endif /* TIMER1_PRIVATE_H_ */