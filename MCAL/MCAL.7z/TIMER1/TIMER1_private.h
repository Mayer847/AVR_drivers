#ifndef TIMER1_PRIVATE_H_
#define TIMER1_PRIVATE_H_
#include "../../LIB/STD_TYPES.h"
#include "../../LIB/BIT_MATH.h"


#define TCCR1A	*((volatile u8*) 0x4f)
#define TCCR1B  *((volatile u8*) 0x4e)



#endif /* TIMER1_PRIVATE_H_ */