/*define cpu 16 MHz clock external clock*/
#define F_CPU 16000000UL	
/*delay*/
#include <util/delay.h>
/*MCAL*/
#include "../MCAL/DIO/Dio_interface.h"
#include "../MCAL/GIE/GIE_interface.h"
#include "../MCAL/EXTI0/EXTI0_interface.h"
#include "../MCAL/EXTI1/EXTI1_interface.h"
#include "../MCAL/ADC/ADC_interface.h"
#include "../MCAL/TIMER/TIMER_interface.h"
/*HAL*/
#include "../HAL/LED/LED_interface.h"
#include "../HAL/SW/SW_interface.h"
#include "../HAL/LCD/LCD_interface.h"

/*APP (FUNCTIONS) */
#include "Timer.h"
#include "Extint.h"
#include "ADC.h"
#include "Hamoksha.h"
#include "watch_alarm.h"


int main(void)
{
/**************** SETTING PIN DIRECTION **********/

	Dio_voidSetPinDirection(PORT_A,PIN4,OUTPUT);/* LED */
	Dio_voidSetPinDirection(PORT_A,PIN0,INPUT);/* LDR ADC0 */
	Dio_voidSetPinDirection(PORT_A,PIN1,INPUT);/* LDR ADC1 */
	Dio_voidSetPinDirection(PORT_C,PIN6,OUTPUT);/* BUZZER */
	Dio_voidSetPinDirection(PORT_B,PIN3,OUTPUT);/* CTC or FAST WPM */
	
/**************** INITIALIZATION ****************/
	/*LCD & keypad*/
	LCD_init();
	KP_init();
	
	/*ADC*/
	ADC_init(AVCC,DIV_FAC_128,FREERUN);/*50-250*/
	
	/*TIMER*/
	/*Timer_init(CTC,PRS1024);*/
	Timer_init(NORMAL,PRS1024);
	/*Timer_init(FAST_PWM,PRS1024);*/
	
/******************* INTERRUPTS ******************/	

/*Enable all interrupts( GLOBAL)*/
	gie_enable();
	
/*external interrupts*/
	/*EXTI0_init();*/
	EXTI1_init();
	
/*ADC interrupts*/
	ADCI_EN();
	
/*call back functions*/
	callback_exti1(&EXTI1_flag);
	/*callback_exti1(&EXTI1_reset);*/ /* under development */
	callback_ADC(&ADC_flag);
	callback_tmr(&TIMER_cnt);
	
/*enabling interrupts (GICR)*/
	/*EXTI0_en();*/	/*under development*/
	EXTI1_en();

/******************	TESTING ******************/


/* watch alarm */
	/*watch_alarm();*/
		
	while(1){
	
		
	/* fast PWM testing with buzzer on KP (FAST_PWM mode) */
		/*Timer_kpBuzzer();*/
		
	/* Timer to toggle LED every second + stop using ext. interrupt on KP (NORMAL mode) */
		/*Timer_tglLed();*/
	/* external interrupt for counter & external interrupt to stop/start timer (timer LED stops/starts) (NORMAL mode) */	
		/*ExtInt_kpCntr();*/
		
	/* ADC: LDR and potentiometer */
		/*LDR_read();*/
		
	/* Hamoksha hates the sun */
		/*Hamoksha_hatestheSun();*/
		
	/* Hamoksha goes to sleep */
		/*Hamoksha_sleep();*/
	
	/* ADC: LM */
		LM_read();
	}
}



