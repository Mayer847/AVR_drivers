#ifndef LCD_KP_H_
#define LCD_KP_H_

#include "../HAL/SW/SW_interface.h"



void Lcd_kp_tests(){
/*LCD TESTS & KEY PAD TESTS 	*/

	LCD_voidPrintStr("test123");
	_delay_ms(500);
	LCD_voidCls();
	LCD_voidPrintNum(71);
	_delay_ms(500);
	LCD_voidCls();	
	/********* password function (hint: passord is 1234) ********/
	KP_password();
	/********** simple calculator **********************************/
	SW_u8Calc(); 
	while(1){
		
		while(KP_getChar()==NOT_PRESSED);
		u8 temp=KP_getChar();
		if(temp != NOT_PRESSED)
			LCD_voidWriteData(temp);
		
	}
}

#endif