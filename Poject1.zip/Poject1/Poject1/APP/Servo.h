#define F_CPU 16000000UL
#include <util/delay.h>

#include "../LIB/STD_TYPES.h"
#include "../LIB/BIT_MATH.h"
#include "../MCAL/TIMER1/TIMER1_interface.h"

int main(void){
	
	
	while(1){
	}
}