/*
 * LED_private.h
 *
 * Created: 6/10/2023 9:53:24 PM
 *  Author: Mayer
 */ 


#ifndef LED_PRIVATE_H_
#define LED_PRIVATE_H_





#endif /* LED_PRIVATE_H_ */