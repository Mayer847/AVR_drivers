/*
 * _7SEG_interface.h
 *
 * Created: 6/10/2023 11:16:06 PM
 *  Author: Mayer
 */ 


#ifndef 7SEG_INTERFACE_H_
#define 7SEG_INTERFACE_H_





#endif /* 7SEG_INTERFACE_H_ */