/*
 * _7SEG_private.h
 *
 * Created: 6/10/2023 11:16:47 PM
 *  Author: Mayer
 */ 


#ifndef 7SEG_PRIVATE_H_
#define 7SEG_PRIVATE_H_

//PB0,PB1,PB2,PB4 => 1,2,4,8  DECODER 
//PB6,PB5,PA2,PA3 => COM4,COM3,COM2,COM1
//(turn off DIP LCD switch) before using 7Segments display




#endif /* 7SEG_PRIVATE_H_ */