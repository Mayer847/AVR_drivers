/*
 * SW_interface.h
 *
 * Created: 6/10/2023 11:14:34 PM
 *  Author: Mayer
 */ 


#ifndef SW_INTERFACE_H_
#define SW_INTERFACE_H_

#include "SW_config.h"

#define BUZZ_PORT PORT_C
#define BUZZ_PIN PIN6


u8 SW_getSwSt(u8 PORTID,u8 UPINID);
//void sw_voidLED_ON(u8 PORTID, u8 PINID);

void KP_init();
u8 KP_getChar();
void KP_password();
u8 SW_u8Calc();

#endif /* SW_INTERFACE_H_ */