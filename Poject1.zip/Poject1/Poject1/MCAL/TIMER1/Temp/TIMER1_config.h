/*
 * TIMER1_config.h
 *
 * Created: 6/19/2023 2:21:20 PM
 *  Author: Mayer
 */ 


#ifndef TIMER1_CONFIG_H_
#define TIMER1_CONFIG_H_





#endif /* TIMER1_CONFIG_H_ */