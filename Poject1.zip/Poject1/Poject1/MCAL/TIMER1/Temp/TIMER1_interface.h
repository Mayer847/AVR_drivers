/*
 * TIMER1_interface.h
 *
 * Created: 6/19/2023 2:20:42 PM
 *  Author: Mayer
 */ 


#ifndef TIMER1_INTERFACE_H_
#define TIMER1_INTERFACE_H_

/* TCCR1A */
#define COM1A1  7		/*NORMAL ,, ...*/
#define COM1A0  6
#define COM1B1  5
#define COM1B0  4	
#define FOC1A   3
#define FOC1B   2
#define WGM11   1
#define WGM10   0 

/* TCCR1B */
#define ICNC1   7
#define ICES1   6
/* bit 5 reserved */
#define WGM13   4
#define WGM12   3
#define CS12    2
#define CS11    1
#define CS10    0


#define NORMAL   0
#define PWM		 1
#define CTC		 2
#define FAST_PWM 3


 void Timer1_init(u8 WGM_mode, u8 clock_select);
 void Timer1_stop();
 void Timer1_start(u8 clock_select);
 void callback_tmr1(void (*function_name)(void));
 void Timer1_compMatch(u8 compMatchOutput);
 void Timer1_setComOutMOdeFast(u8 comOutFast);
 void Timer1_setComOutModeNon(u8 comOutNon);

#endif /* TIMER1_INTERFACE_H_ */