/*
 * TIMER1_prog.c
 *
 * Created: 6/19/2023 2:19:26 PM
 *  Author: Mayer
 */ 

#include "../../LIB/STD_TYPES.h"
#include "../../LIB/BIT_MATH.h"
#include "TIMER1_interface.h"
#include "../DIO/Dio_interface.h"

void Timer1_init(u8 WGM_mode, u8 clock_select){
	
	//SET_BIT(TIMSK_REG,TOIE0);

	Dio_voidSetPinDirection(PORT_D,PIN4,OUTPUT); /* OC1A & OC1B*/
	/* 1110 FAST PWM */
	TCCR1A|= 0b00000010;
	TCCR1B|= 0b00011000;
		
	/* COM1B1, COM1B0 SET TO CLEAR ON COMPARE*/
	TCCR1B|= 0b00110000;
	
}

