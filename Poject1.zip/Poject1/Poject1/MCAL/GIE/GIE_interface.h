/*
 * GIE_interface.h
 *
 * Created: 6/16/2023 2:41:26 PM
 *  Author: Mayer
 */ 


#ifndef GIE_INTERFACE_H_
#define GIE_INTERFACE_H_

#include "GIE_private.h"

void gie_enable();
void gie_disable();


#endif /* GIE_INTERFACE_H_ */