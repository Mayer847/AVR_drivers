/*
 * TIMER_prog.c
 *
 * Created: 6/18/2023 10:45:00 AM
 *  Author: Mayer
 */ 

#include "../../LIB/STD_TYPES.h"
#include "../../LIB/BIT_MATH.h"
#include "TIMER_interface.h"
#include "../DIO/Dio_interface.h"
static void (*pf_tmr) (void);

void Timer_init(u8 WGM_mode, u8 clock_select){
	
	SET_BIT(TIMSK_REG,TOIE0);
	
	switch (WGM_mode)
	{
		case NORMAL:
			TCCR0_REG->TCCR0_WGM00=0;
			TCCR0_REG->TCCR0_WGM01=0;
			break;
		case PWM:
			TCCR0_REG->TCCR0_WGM00=1;
			TCCR0_REG->TCCR0_WGM01=0;
			break;
		case CTC:
			TCCR0_REG->TCCR0_WGM00=0;
			TCCR0_REG->TCCR0_WGM01=1;
			break;
		case FAST_PWM:
			TCCR0_REG->TCCR0_WGM00=1;
			TCCR0_REG->TCCR0_WGM01=1;
			break;
	}
	

	switch(clock_select)
	{
		case NO_CLOCK:
			TCCR0_REG->TCCR0_CS0=0;break;
		case NO_PRS:
			TCCR0_REG->TCCR0_CS0=1;break;
		case PRS8:
			TCCR0_REG->TCCR0_CS0=2;break;
		case PRS64:
			TCCR0_REG->TCCR0_CS0=3;break;
		case PRS256:
			TCCR0_REG->TCCR0_CS0=4;break;
		case PRS1024:
			TCCR0_REG->TCCR0_CS0=5;break;
		case EXT_CLK_F:
			TCCR0_REG->TCCR0_CS0=6;break;
		case EXT_CLK_R:
			TCCR0_REG->TCCR0_CS0=7;break;
	}
	if(WGM_mode==CTC || WGM_mode==FAST_PWM)
	{
		Dio_voidSetPinDirection(PORT_B,PIN3,OUTPUT); /*e OC0 pin must be set in order to enable the output driver.*/
		/*Bit 5:4 � COM01:0: Compare Match Output Mode*/
		CLR_BIT(TCCR0,COM00);
		SET_BIT(TCCR0,COM01);/*OVERRIDES THE NORMAL PORT FUNCTIONALITY OF I/O PIN IT IS CONNECTED TO*/
	}
	
}

void Timer_setComOutModeNon(u8 comOutNon)
{
	Dio_voidSetPinDirection(PORT_B,PIN3,OUTPUT);
	switch(comOutNon)
	{
		case NORM_OC0:
			CLR_BIT(TCCR0,COM00);
			CLR_BIT(TCCR0,COM01);break;
		case TGL_OC0:	 
			SET_BIT(TCCR0,COM00);
			CLR_BIT(TCCR0,COM01);break;
		case CLR_OC0:	 
			CLR_BIT(TCCR0,COM00);
			SET_BIT(TCCR0,COM01);break;
		case SET_OC0:	 
			SET_BIT(TCCR0,COM00);
			SET_BIT(TCCR0,COM01);break;
	}
}

void Timer_compMatch(u8 compMatchOutput)
{
	OCR0 = compMatchOutput*255/100;
}

void Timer_setComOutMOdeFast(u8 comOutFast)
{
	Dio_voidSetPinDirection(PORT_B,PIN3,OUTPUT);
	switch(comOutFast)
	{
		case NORM_OC0:
		CLR_BIT(TCCR0,COM00);
		CLR_BIT(TCCR0,COM01);break;
		case CLR_OC0:
		CLR_BIT(TCCR0,COM00);
		SET_BIT(TCCR0,COM01);break;
		case SET_OC0:
		SET_BIT(TCCR0,COM00);
		SET_BIT(TCCR0,COM01);break;
	}
}
void Timer_stop(){
	//CS02 CS01 CS00 => 000
	TCCR0_REG->TCCR0_CS0=NO_CLOCK;
	/*TCCR0&=0b11111000;*/
}

void Timer_start(u8 clock_select){
	/* counter or timer? last three options in the table are for counter */
		switch(clock_select)
		{
			case NO_PRS:
				TCCR0_REG->TCCR0_CS0=1;break;
			case PRS8:
				TCCR0_REG->TCCR0_CS0=2;break;
			case PRS64:
				TCCR0_REG->TCCR0_CS0=3;break;
			case PRS256:
				TCCR0_REG->TCCR0_CS0=4;break;
			case PRS1024:
				TCCR0_REG->TCCR0_CS0=5;break;
			case EXT_CLK_F:
				TCCR0_REG->TCCR0_CS0=6;break;
			case EXT_CLK_R:
				TCCR0_REG->TCCR0_CS0=7;break;
		}
}

void callback_tmr(void (*function_name)(void))
{
	if (function_name!= NULL)
	{
		pf_tmr=function_name;
	}

}

void __vector_11 (void) __attribute__((signal,used));

void __vector_11 (void)
{
	
	pf_tmr();

}